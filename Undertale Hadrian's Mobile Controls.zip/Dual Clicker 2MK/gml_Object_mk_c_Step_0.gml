var left_side_x1;
var left_side_x2;
var left_side_y1;
var left_side_y2;
var right_side_x1;
var right_side_x2;
var right_side_y1;
var right_side_y2;
var mouse_in_left;
var mouse_in_right;

for (var i = 0; i < 32; i++)
{
    var left_side_x1 = -200;
    var left_side_x2 = -1;
    var left_side_y1 = -200;
    var left_side_y2 = 680;
    var right_side_x1 = 640;
    var right_side_x2 = 840;
    var right_side_y1 = -200;
    var right_side_y2 = 680;
    var mouse_in_left = device_mouse_x_to_gui(i) > left_side_x1 && device_mouse_x_to_gui(i) < left_side_x2 && device_mouse_y_to_gui(i) > left_side_y1 && device_mouse_y_to_gui(i) < left_side_y2;
    var mouse_in_right = device_mouse_x_to_gui(i) > right_side_x1 && device_mouse_x_to_gui(i) < right_side_x2 && device_mouse_y_to_gui(i) > right_side_y1 && device_mouse_y_to_gui(i) < right_side_y2;

    if (mouse_in_left && mouse_check_button_pressed(mb_left))
    {
        if (last_side == "left" && (current_time - time_lastclick) < limit_time)
        {
            if (global.mbk == 0)
            {
                global.mbk = 1;
                global.dual = 0;
                audio_play_sound(xbox_live_notification, 0, false);
            }
            else if (global.mbk == 1)
            {
                global.mbk = 0;
                global.dual = 0;
                audio_play_sound(Windows_Notify_Email, 0, false);
            }
        }
    
        clicks_left += 1;
        last_side = "left";
        time_lastclick = current_time;
    }

    if (mouse_in_right && mouse_check_button_pressed(mb_left))
    {
        clicks_right += 1;
        last_side = "right";
        time_lastclick = current_time;
    }

    if (mouse_in_left && mouse_check_button_pressed(mb_right))
    {
        if (global.mbk == 0)
        {
            global.mbk = 1;
            global.dual = 0;
            audio_play_sound(xbox_live_notification, 0, false);
        }
        else if (global.mbk == 1)
        {
            global.mbk = 0;
            global.dual = 0;
            audio_play_sound(Windows_Notify_Email, 0, false);
        }
    }
}
