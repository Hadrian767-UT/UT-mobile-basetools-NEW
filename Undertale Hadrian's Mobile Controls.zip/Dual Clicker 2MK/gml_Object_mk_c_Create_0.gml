last_side = "";
clicks_left = 0;
clicks_right = 0;
time_lastclick = 0;
limit_time = 30;
