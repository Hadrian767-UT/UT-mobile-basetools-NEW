draw_sprite_ext(spr_black, 0, 0, 0, 1, 1, 0, c_white, black_fade);
draw_set_font(settings_font);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_sprite_ext(spr_controls_config, 0, 220, 22.5, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_arrow_leftright, 0, joystick_type ? 120.5 : 459.5, 75, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_button_scale, 0, joystick_type ? 210.5 : 120.5, 75, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_arrow_leftright, 0, joystick_type ? 120.5 : 459.5, 145, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_analog_type, 0, joystick_type ? 210.5 : 124, 145, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_arrow_leftright, 0, joystick_type ? 120.5 : 459.5, 213, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_controls_opacity, 0, joystick_type ? 210.5 : 106.5, 213, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_reset_config, 0, 241, 412.25, 2, 2, 0, c_white, text_black_fade);
draw_text_colour(joystick_type ? 140 : settings_num_x, 67, button_scale, c_white, c_white, c_white, c_white, text_black_fade);
draw_text_colour(joystick_type ? 140 : settings_num_x, 135, joystick_type, c_white, c_white, c_white, c_white, text_black_fade);
draw_text_colour(joystick_type ? settings_num_opacity : settings_num_x, 205, controls_opacity, c_white, c_white, c_white, c_white, text_black_fade);
draw_sprite_ext(spr_z_button, keyboard_check(ord("Z")), zx, zy, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_x_button, keyboard_check(ord("X")), xx, xy, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_c_button, keyboard_check(ord("C")), cx, cy, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_1_button, keyboard_check(vk_up), onex, oney, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_2_button, keyboard_check(vk_down), twox, twoy, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_3_button, keyboard_check(vk_left), threex, threey, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_4_button, keyboard_check(vk_right), fourx, foury, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_1_button, keyboard_check(ord("W")), fivex, fivey, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_2_button, keyboard_check(ord("S")), sixx, sixy, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_3_button, keyboard_check(ord("A")), sevenx, seveny, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_4_button, keyboard_check(ord("D")), eightx, eighty, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_settings, keyboard_check(92), settingsx, settingsy, 3, 3, 0, c_white, controls_opacity);
draw_sprite_ext(spr_r_button, keyboard_check(vk_f2), rx, ry, 2.5, 2.5, 0, c_white, controls_opacity);

if (global.debug_legally == 1)
    draw_sprite_ext(spr_bugbutton, keyboard_check(ord("T")), debugx, debugy, 3, 3, 0, c_white, controls_opacity);

draw_sprite_ext(spr_settings, keyboard_check(ord("V")), dualx, dualy, 3, 3, 0, c_rainbow, controls_opacity + 0.3);
awa += 1.45;
c_rainbow = make_color_hsv(awa % 223, 255, 200);
