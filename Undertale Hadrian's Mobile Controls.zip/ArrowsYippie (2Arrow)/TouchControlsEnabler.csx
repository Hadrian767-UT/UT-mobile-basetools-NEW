// Made by GitMuslim, Some fixes by NC-devC
// Before you use it, add the Joystick first!

using System;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Linq;
using UndertaleModLib.Util;

EnsureDataLoaded();

string displayName = Data.GeneralInfo?.DisplayName?.Content.ToLower();

if (displayName != "deltarune chapter 1 & 2" && displayName != "deltarune chapter 1&2" && displayName != "undertale")
{
    if (!ScriptQuestion("Скрипт был создан любителем андертейл игр и просто этой программы(Undertale Mod Tool) Илка МП(мной), поэтому да, поддержи меня если можешь, присоединяйся в мой телеграм канал JustTale Studio. Убедись что в твоей игре есть шрифты, без них не будет работать скрипт! А теперь нажми Ок или Да для продолжения"))
    {
        return;
    }
}

string dataPath = Path.Combine(Path.GetDirectoryName(ScriptPath), "TouchControls_data");

Dictionary<string, UndertaleEmbeddedTexture> textures = new Dictionary<string, UndertaleEmbeddedTexture>();

UndertaleEmbeddedTexture controlsTexturePage = new UndertaleEmbeddedTexture();
controlsTexturePage.TextureData.Image = GMImage.FromPng(File.ReadAllBytes(Path.Combine(dataPath, "buttons.png"))); // TODO: generate other formats
Data.EmbeddedTextures.Add(controlsTexturePage);
textures.Add(Path.GetFileName(Path.Combine(dataPath, "buttons.png")), controlsTexturePage);

UndertaleTexturePageItem AddNewTexturePageItem(ushort sourceX, ushort sourceY, ushort sourceWidth, ushort sourceHeight)
{
    ushort targetX = 0;
    ushort targetY = 0;
    ushort targetWidth = sourceWidth;
    ushort targetHeight = sourceHeight;
    ushort boundingWidth = sourceWidth;
    ushort boundingHeight = sourceHeight;
    var texturePage = textures["buttons.png"];

    UndertaleTexturePageItem tpItem = new() 
    { 
        SourceX = sourceX, 
        SourceY = sourceY, 
        SourceWidth = sourceWidth, 
        SourceHeight = sourceHeight, 
        TargetX = targetX, 
        TargetY = targetY, 
        TargetWidth = targetWidth, 
        TargetHeight = targetHeight, 
        BoundingWidth = boundingWidth, 
        BoundingHeight = boundingHeight, 
        TexturePage = texturePage, 
        Name = new UndertaleString($"PageItem {Data.TexturePageItems.Count}")
    };
    Data.TexturePageItems.Add(tpItem);
    return tpItem;
}

UndertaleTexturePageItem pg_1_button = AddNewTexturePageItem(944, 2, 27, 29);
UndertaleTexturePageItem pg_1_button_p = AddNewTexturePageItem(895, 68, 27, 27);
pg_1_button_p.TargetY = 2;
pg_1_button_p.BoundingHeight = 29;
UndertaleTexturePageItem pg_2_button = AddNewTexturePageItem(851, 2, 27, 29);
UndertaleTexturePageItem pg_2_button_p = AddNewTexturePageItem(968, 35, 27, 27);
pg_2_button_p.TargetY = 2;
pg_2_button_p.BoundingHeight = 29;
UndertaleTexturePageItem pg_3_button = AddNewTexturePageItem(882, 2, 27, 29);
UndertaleTexturePageItem pg_3_button_p = AddNewTexturePageItem(968, 66, 27, 27);
pg_3_button_p.TargetY = 2;
pg_3_button_p.BoundingHeight = 29;
UndertaleTexturePageItem pg_4_button = AddNewTexturePageItem(875, 35, 27, 29);
UndertaleTexturePageItem pg_4_button_p = AddNewTexturePageItem(864, 68, 27, 27);
pg_4_button_p.TargetY = 2;
pg_4_button_p.BoundingHeight = 29;

void AddNewUndertaleSprite(string spriteName, ushort width, ushort height, UndertaleTexturePageItem[] spriteTextures)
{
    var name = Data.Strings.MakeString(spriteName);
    ushort marginLeft = 0;
    int marginRight = width - 1;
    ushort marginTop = 0;
    int marginBottom = height - 1;

    var sItem = new UndertaleSprite { Name = name, Width = width, Height = height, MarginLeft = marginLeft, MarginRight = marginRight, MarginTop = marginTop, MarginBottom = marginBottom };
    foreach (var spriteTexture in spriteTextures) 
    {
        sItem.Textures.Add(new UndertaleSprite.TextureEntry() { Texture = spriteTexture });
    }
    Data.Sprites.Add(sItem);
}

AddNewUndertaleSprite("spr_1_button", 27, 29, new UndertaleTexturePageItem[] {pg_1_button, pg_1_button_p});
AddNewUndertaleSprite("spr_2_button", 27, 29, new UndertaleTexturePageItem[] {pg_2_button, pg_2_button_p});
AddNewUndertaleSprite("spr_3_button", 27, 29, new UndertaleTexturePageItem[] {pg_3_button, pg_3_button_p});
AddNewUndertaleSprite("spr_4_button", 27, 29, new UndertaleTexturePageItem[] {pg_4_button, pg_4_button_p});

string currentFont = "";
var fntMain = Data.Fonts.Any(o => o.Name.Content.ToLower() == "fnt_main");

if (fntMain)
{
    currentFont = "fnt_main";
}
else
{
    var fntMainBig = Data.Fonts.Any(o => o.Name.Content.ToLower() == "fnt_mainbig");
    if (fntMainBig)
    {
        currentFont = "fnt_mainbig";
    }
    else
    {
        currentFont = Data.Fonts.First().Name.Content;
    }
}

int settingsnumx = 0;
if(currentFont == "fnt_main") {settingsnumx = 477; }
else if(currentFont == "fnt_mainbig") { settingsnumx = 502; }

UndertaleModLib.Compiler.CodeImportGroup importGroup = new(Data);

string mobileControlsCreate = File.ReadAllText(Path.Combine(dataPath, "gml_Object_obj_mobilebuttons_Create_0.gml"));
StringBuilder builder = new StringBuilder(mobileControlsCreate);
builder.Replace("{_font}", currentFont);
builder.Replace("{_settingsnumx}", Convert.ToString(settingsnumx));
mobileControlsCreate = builder.ToString();

importGroup.QueueReplace("gml_Object_obj_mobilebuttons_Create_0", mobileControlsCreate);
QueueGMLFile(Path.Combine(dataPath, "gml_Object_obj_mobilebuttons_Draw_75.gml"));
QueueGMLFile(Path.Combine(dataPath, "gml_Object_obj_mobilebuttons_Other_4.gml"));
Data.Scripts.Add(new UndertaleScript() { Name = Data.Strings.MakeString("scr_add_buttons"), Code = Data.Code.ByName("gml_Object_obj_mobilebuttons_Other_4") });
QueueGMLFile(Path.Combine(dataPath, "gml_Object_obj_mobilebuttons_Step_0.gml"));

var mobileControls = Data.GameObjects.ByName("obj_mobilebuttons");
mobileControls.Persistent = true;

importGroup.Import();

void QueueGMLFile(string path)
{
    importGroup.QueueReplace(Path.GetFileNameWithoutExtension(path), File.ReadAllText(path));
}
