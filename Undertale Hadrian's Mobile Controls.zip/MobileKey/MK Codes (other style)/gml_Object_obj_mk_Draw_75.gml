draw_set_alpha(0.75);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_alpha(0.75)
draw_set_color(c_green)
draw_roundrect(400, 460, 480, 480, 0)
draw_set_color(c_orange)
draw_roundrect(480, 420, 560, 460, 0)
draw_set_color(c_aqua)
draw_roundrect(560, 420, 640, 460, 0)
draw_set_color(c_white)
draw_roundrect(560, 0, 640, 30, 0)
draw_set_alpha(1.5);
draw_sprite_ext(control_joy, 0, 140, 360, 2, 2, 0, c_white, 0.41);
draw_set_color(c_white);
