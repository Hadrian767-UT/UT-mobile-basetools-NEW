if (keyboard_check(vk_anykey))
{
    switch (keyboard_key)
    {
        case vk_enter:
        case ord("Z"):
            show_debug_message("vk_enter");
            break;
        
        case vk_shift:
        case ord("X"):
            show_debug_message("vk_shift");
            break;
        
        case ord("C"):
            show_debug_message("C");
            break;
        
        case vk_up:
            show_debug_message("vk_up");
            break;
        
        case vk_down:
            show_debug_message("vk_down");
            break;
        
        case vk_left:
            show_debug_message("vk_left");
            break;
        
        case vk_right:
            show_debug_message("vk_right");
            break;
        
        case ord("W"):
            show_debug_message("W");
            break;
        
        case ord("A"):
            show_debug_message("A");
            break;
        
        case ord("S"):
            show_debug_message("S");
            break;
        
        case ord("D"):
            show_debug_message("D");
            break;
    }
}
