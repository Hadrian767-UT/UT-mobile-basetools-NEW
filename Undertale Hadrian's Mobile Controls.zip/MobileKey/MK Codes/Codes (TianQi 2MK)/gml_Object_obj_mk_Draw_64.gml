if (global._is_debug == 1)
{
    ca++;
    HSV = make_color_hsv(ca % 255, 255, 255);
    draw_set_color(HSV);
    draw_set_alpha(0.5);
    draw_roundrect_ext(10, 50, 92, 90, 20, 20, 0);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_ext(12 + i, 52 + i, 90 - i, 88 - i, 20, 20, 1);
        i += 0.1;
    }
    
    draw_set_alpha(0.5);
    draw_set_font(th_ui);
    draw_text(25, 62, "Debug");
    draw_set_color(c_white);
}

draw_set_color(c_white);
var iColor = make_color_rgb(229, 123, 158);
var i_green = merge_color(c_green, iColor, 0);
var i_orange = merge_color(c_orange, iColor, 0);
var i_aqua = merge_color(c_aqua, iColor, 0);
draw_set_alpha(0.5);
draw_set_font(th_ui);
draw_set_halign(fa_left);

if (_mb_d == 1)
{
    draw_set_color(i_green);
    draw_roundrect_ext(380, 0, 460, 20, 20, 20, 0);
    draw_set_alpha(0.7);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_ext(382 + i, 2 + i, 458 - i, 18 - i, 20, 20, 1);
        i += 0.1;
    }
    
    draw_set_alpha(0.8);
    draw_set_color(c_white);
    draw_text(415, 0, "C");
}
else
{
    draw_set_color(i_green);
    draw_roundrect_ext(380, 420, 460, 440, 20, 20, 0);
    draw_set_alpha(0.7);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_ext(382 + i, 422 + i, 458 - i, 438 - i, 20, 20, 1);
        i += 0.1;
    }
    
    draw_set_alpha(0.8);
    draw_set_color(c_white);
    draw_text(415, 420, "C");
}

if (_mb_d == 1)
{
    draw_set_alpha(0.5);
    draw_set_color(i_orange);
    draw_roundrect_ext(460, 0, 540, 40, 20, 20, 0);
    draw_set_alpha(0.7);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_ext(462 + i, 2 + i, 538 - i, 38 - i, 20, 20, 1);
        i += 0.1;
    }
    
    draw_set_alpha(0.8);
    draw_set_color(c_white);
    draw_text(480, 10, "Shift");
}
else
{
    draw_set_alpha(0.5);
    draw_set_color(i_orange);
    draw_roundrect_ext(460, 400, 540, 440, 20, 20, 0);
    draw_set_alpha(0.7);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_ext(462 + i, 402 + i, 538 - i, 438 - i, 20, 20, 1);
        i += 0.1;
    }
    
    draw_set_alpha(0.8);
    draw_set_color(c_white);
    draw_text(480, 410, "Shift");
}

if (_mb_d == 1)
{
    draw_set_alpha(0.5);
    draw_set_color(i_aqua);
    draw_roundrect_ext(540, 0, 620, 40, 20, 20, 0);
    draw_set_alpha(0.7);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_ext(542 + i, 2 + i, 618 - i, 38 - i, 20, 20, 1);
        i += 0.1;
    }
    
    draw_set_alpha(0.8);
    draw_set_color(c_white);
    draw_text(558, 10, "Enter");
    draw_set_alpha(1);
}
else
{
    draw_set_alpha(0.5);
    draw_set_color(i_aqua);
    draw_roundrect_ext(540, 400, 620, 440, 20, 20, 0);
    draw_set_alpha(0.7);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_ext(542 + i, 402 + i, 618 - i, 438 - i, 20, 20, 1);
        i += 0.1;
    }
    
    draw_set_alpha(0.8);
    draw_set_color(c_white);
    draw_text(558, 410, "Enter");
    draw_set_alpha(1);
}

draw_set_alpha(0.5);
draw_set_color(c_mb_d);
draw_roundrect_ext(10, 0, 92, 40, 20, 20, 0);
draw_set_alpha(0.7);
i = 0;

while (i < 2)
{
    draw_roundrect_ext(12 + i, 2 + i, 90 - i, 38 - i, 20, 20, 1);
    i += 0.1;
}

draw_set_alpha(1);
draw_set_color(c_white);
draw_text(36, 7, "切");
draw_set_alpha(0.5);
draw_set_color(c_teal);
draw_roundrect_ext(102, 0, 194, 40, 20, 20, 0);
draw_set_alpha(0.7);
i = 0;

while (i < 2)
{
    draw_roundrect_ext(104 + i, 2 + i, 192 - i, 38 - i, 20, 20, 1);
    i += 0.1;
}

draw_set_alpha(1);
draw_set_color(c_white);
draw_text(138, 7, "吃");

if (global._is_debug == 1)
{
    draw_set_alpha(0.5);
    draw_set_color(c_blue);
    draw_roundrect_ext(10, 100, 92, 140, 20, 20, 0);
    draw_set_alpha(0.7);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_ext(12 + i, 102 + i, 90 - i, 138 - i, 20, 20, 1);
        i += 0.1;
    }
    
    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_text(35, 110, "fps");
}

draw_set_alpha(1);
draw_sprite_ext(control_joy, 0, 80, 300, 2, 2, 0, c_white, 0.5);

if (_mb_d == 1)
    draw_sprite_ext(control_joy, 0, 432, 300, 2, 2, 0, c_white, 0.5);
