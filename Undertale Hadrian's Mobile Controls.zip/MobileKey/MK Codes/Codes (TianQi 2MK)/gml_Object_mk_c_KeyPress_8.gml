if (global.isFeatureEnabled == 1)
{
    global.isFeatureEnabled = 0;
    instance_destroy(obj_mk);
    audio_play_sound(Windows_Notify_Email, 10, false);
}
else if (global.isFeatureEnabled == 0)
{
    global.isFeatureEnabled = 1;
    instance_create_depth(0, 0, depth, obj_mk);
    audio_play_sound(xbox_live_notification, 10, false);
}
