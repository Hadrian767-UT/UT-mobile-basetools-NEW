if (game_get_speed(gamespeed_fps) == 60)
    game_set_speed(10, gamespeed_fps);
else if (game_get_speed(gamespeed_fps) == 10)
    game_set_speed(3, gamespeed_fps);
else if (game_get_speed(gamespeed_fps) == 3)
    game_set_speed(60, gamespeed_fps);
