for (var j = 0; j < 32; j++)
{
    if (device_mouse_check_button(j, mb_left))
    {
        _m = 1;
        var _dx = device_mouse_x_to_gui(i) - 140;
        var _ex = device_mouse_x_to_gui(j) - 500;
        var _dy = device_mouse_y_to_gui(i) - 360;
        var _ey = device_mouse_y_to_gui(j) - 360;
        var _da = point_direction(0, 0, _dx, _dy);
        var _ea = point_direction(0, 0, _ex, _ey);
        var _devxo = device_mouse_x_to_gui(i);
        var _devxt = device_mouse_x_to_gui(j);
        var _devyo = device_mouse_y_to_gui(i);
        var _devyt = device_mouse_y_to_gui(j);
        
        if (_devxo <= 320)
        {
            if (_da >= 292.5 || _da <= 67.5)
            {
                cr = 0.5;
                
                if (_ak == 0)
                    _ak = 39;
                else
                    _ak2 = 39;
            }
            
            if (_da >= 22.5 && _da <= 157.5)
            {
                cu = 0.5;
                
                if (_ak == 0)
                    _ak = 38;
                else
                    _ak2 = 38;
            }
            
            if (_da >= 112.5 && _da <= 247.5)
            {
                cl = 0.5;
                
                if (_ak == 0)
                    _ak = 37;
                else
                    _ak2 = 37;
            }
            
            if (_da >= 202.5 && _da <= 337.5)
            {
                cd = 0.5;
                
                if (_ak == 0)
                    _ak = 40;
                else
                    _ak2 = 40;
            }
        }
        
        if (_devxt >= 320 && _devyt > 40)
        {
            if (_ea >= 292.5 || _ea <= 67.5)
            {
                dr = 0.5;
                
                if (_ak == 0)
                    _ak = 68;
                else
                    _ak2 = 68;
            }
            
            if (_ea >= 22.5 && _ea <= 157.5)
            {
                du = 0.5;
                
                if (_ak == 0)
                    _ak = 87;
                else
                    _ak2 = 87;
            }
            
            if (_ea >= 112.5 && _ea <= 247.5)
            {
                dl = 0.5;
                
                if (_ak == 0)
                    _ak = 65;
                else
                    _ak2 = 65;
            }
            
            if (_ea >= 202.5 && _ea <= 337.5)
            {
                dd = 0.5;
                
                if (_ak == 0)
                    _ak = 83;
                else
                    _ak2 = 83;
            }
        }
    }
}
