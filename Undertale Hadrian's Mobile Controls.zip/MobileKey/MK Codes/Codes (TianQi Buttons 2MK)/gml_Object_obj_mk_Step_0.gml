cu = 1;
cd = 1;
cl = 1;
cr = 1;
du = 1;
dd = 1;
dl = 1;
dr = 1;
cz = 1;
cx = 1;
cg = 1;
_m = 0;
debugbutton = 1;
dualclickerbutton = 1;
f2button = 1;

for (i = 0; i < 4; i++)
{
    _ak = 0;
    _ak2 = 0;
    
    if (device_mouse_check_button(i, mb_left))
    {
        if (device_mouse_x_to_gui(i) >= 540 && device_mouse_y_to_gui(i) < 40)
        {
            cz = 0.5;
            _ak = 90;
        }
        else if (device_mouse_x_to_gui(i) >= 460 && device_mouse_y_to_gui(i) < 40)
        {
            cx = 0.5;
            _ak = 88;
        }
        else if (device_mouse_x_to_gui(i) >= 380 && device_mouse_y_to_gui(i) < 40)
        {
            cg = 0.5;
            _ak = 67;
        }
        else if (device_mouse_x_to_gui(i) >= 10 && device_mouse_x_to_gui(i) <= 90 && device_mouse_y_to_gui(i) >= 90 && device_mouse_y_to_gui(i) <= 130 && global.debug_legally == 1)
        {
            debugbutton = 0.5;
            _ak = 84;
        }
        else if (device_mouse_x_to_gui(i) >= 10 && device_mouse_x_to_gui(i) <= 90 && device_mouse_y_to_gui(i) >= 50 && device_mouse_y_to_gui(i) <= 80)
        {
            dualclickerbutton = 0.5;
            _ak = 86;
        }
        else if (device_mouse_x_to_gui(i) >= 10 && device_mouse_x_to_gui(i) <= 92 && device_mouse_y_to_gui(i) >= 0 && device_mouse_y_to_gui(i) <= 40)
        {
            f2button = 0.5;
            _ak = 113;
        }
        else if (!_m)
        {
            event_user(0);
        }
    }
    
    if (device_mouse_check_button_pressed(i, mb_left))
    {
        if (_ak != 0)
        {
            if (keyboard_check(_ak))
            {
                keyboard_key_release(_ak);
                keyboard_key_press(_ak);
            }
        }
        
        if (_ak2 != 0)
        {
            if (keyboard_check(_ak2))
            {
                keyboard_key_release(_ak2);
                keyboard_key_press(_ak2);
            }
        }
    }
}

if (global.debug_legally == 1)
{
    if (debugbutton == 0.5 && !keyboard_check(ord("T")))
        keyboard_key_press(ord("T"));
}

if (dualclickerbutton == 0.5 && !keyboard_check(ord("V")))
    keyboard_key_press(ord("V"));

if (f2button == 0.5 && !keyboard_check(vk_f2))
    keyboard_key_press(vk_f2);

if (cz == 0.5 && !keyboard_check(ord("Z")))
    keyboard_key_press(ord("Z"));

if (cx == 0.5 && !keyboard_check(ord("X")))
    keyboard_key_press(ord("X"));

if (cg == 0.5 && !keyboard_check(ord("C")))
    keyboard_key_press(ord("C"));

if (cr == 0.5 && !keyboard_check(vk_right))
    keyboard_key_press(vk_right);

if (cu == 0.5 && !keyboard_check(vk_up))
    keyboard_key_press(vk_up);

if (cl == 0.5 && !keyboard_check(vk_left))
    keyboard_key_press(vk_left);

if (cd == 0.5 && !keyboard_check(vk_down))
    keyboard_key_press(vk_down);

if (dr == 0.5 && !keyboard_check(ord("D")))
    keyboard_key_press(ord("D"));

if (du == 0.5 && !keyboard_check(ord("W")))
    keyboard_key_press(ord("W"));

if (dl == 0.5 && !keyboard_check(ord("A")))
    keyboard_key_press(ord("A"));

if (dd == 0.5 && !keyboard_check(ord("S")))
    keyboard_key_press(ord("S"));

if (global.debug_legally == 1)
{
    if (debugbutton == 1 && keyboard_check(ord("T")))
        keyboard_key_release(ord("T"));
}

if (dualclickerbutton == 1 && keyboard_check(ord("V")))
    keyboard_key_release(ord("V"));

if (f2button == 1 && keyboard_check(vk_f2))
    keyboard_key_release(vk_f2);

if (cz == 1 && keyboard_check(ord("Z")))
    keyboard_key_release(ord("Z"));

if (cx == 1 && keyboard_check(ord("X")))
    keyboard_key_release(ord("X"));

if (cg == 1 && keyboard_check(ord("C")))
    keyboard_key_release(ord("C"));

if (cr == 1 && keyboard_check(vk_right))
    keyboard_key_release(vk_right);

if (cu == 1 && keyboard_check(vk_up))
    keyboard_key_release(vk_up);

if (cl == 1 && keyboard_check(vk_left))
    keyboard_key_release(vk_left);

if (cd == 1 && keyboard_check(vk_down))
    keyboard_key_release(vk_down);

if (dr == 1 && keyboard_check(ord("D")))
    keyboard_key_release(ord("D"));

if (du == 1 && keyboard_check(ord("W")))
    keyboard_key_release(ord("W"));

if (dl == 1 && keyboard_check(ord("A")))
    keyboard_key_release(ord("A"));

if (dd == 1 && keyboard_check(ord("S")))
    keyboard_key_release(ord("S"));
