if (file_exists(config_path))
{
    ini_open(config_path);
    global.ui_cc = ini_read_real("Controller", "Changer", 1);
    ini_close();
}

if (file_exists(game_path))
{
    ini_open(game_path);
    cc = ini_read_real("Game", "Ini", 1);
    ini_close();
}
