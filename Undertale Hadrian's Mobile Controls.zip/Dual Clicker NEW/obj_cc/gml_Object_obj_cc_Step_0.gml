if (keyboard_check_pressed(47))
{
    if (cc == 1)
    {
        cc = 0;
        CC_Add("Dual Clicker enabled!");
    }
    else if (cc == 0)
    {
        cc = 1;
        CC_Add("Dual Clicker disabled!");
    }
    
    ini_open(game_path);
    ini_write_real("Game", "Ini", cc);
    ini_close();
}

if (global.ui_cc == 2 && !instance_exists(obj_mk))
{
    instance_create_depth(0, 0, -15998, obj_mk);
}
else if (global.ui_cc == 3 && !instance_exists(obj_mobilecontrols))
{
    instance_create_depth(0, 0, -15998, obj_mobilecontrols);
        
    with (obj_mobilecontrols)
    {
        if (!script_exists(scr_add_keys()))
            scr_add_keys();
    }
}
else if (global.ui_cc == 4 && !instance_exists(obj_mobilebuttons))
{
    instance_create_depth(0, 0, -15998, obj_mobilebuttons);
        
    with (obj_mobilebuttons)
    {
        if (!script_exists(scr_add_buttons()))
            scr_add_buttons();
    }
}

if (cc == 0)
{
    if (device_mouse_x_to_gui(0) < 0 && mouse_check_button_pressed(mb_right))
    {
        with (obj_cc)
            event_perform(ev_keypress, vk_backspace);	
    }
}
