if (global.ui_cc == 2 && !instance_exists(obj_mk))
{
    instance_create_depth(0, 0, -15998, obj_mk);
}
else if (global.ui_cc == 3 && !instance_exists(obj_mobilecontrols))
{
    instance_create_depth(0, 0, -15998, obj_mobilecontrols);
        
    with (obj_mobilecontrols)
    {
        if (!script_exists(scr_add_keys()))
            scr_add_keys();
    }
}
else if (global.ui_cc == 4 && !instance_exists(obj_mobilebuttons))
{
    instance_create_depth(0, 0, -15998, obj_mobilebuttons);
        
    with (obj_mobilebuttons)
    {
        if (!script_exists(scr_add_buttons()))
            scr_add_buttons();
    }
}

if (cc == 0 && !instance_exists(obj_controller_changer))
    instance_create_depth(0, 0, -15998, obj_controller_changer);
else if (cc == 1 && instance_exists(obj_controller_changer))
    instance_destroy(obj_controller_changer);
