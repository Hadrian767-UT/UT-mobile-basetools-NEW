global.debug_legally = 0;
global.ui_cc = 1;
config_path = "CC.ini";
cc = 1;
game_path = "Game.ini";
alarm[0] = 1;
var advice = "If you are modifying this port and will put DEBUG on it, pls, don't make an video using DEBUG ot whatever other methods of cheating. \nThanks for reading ;). \nWritten By: Hadrian767.";
