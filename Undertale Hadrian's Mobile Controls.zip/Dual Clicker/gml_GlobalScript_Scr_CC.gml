if (instance_exists(obj_mk))
{
    instance_destroy(obj_mk);
    instance_create_depth(0, 0, -15998, obj_mobilecontrols);
    audio_play_sound(xbox_live_notification, 0, false);
    CC_Add("Current: Mobile Controls By&GitMuslim");
    
    with (obj_mobilecontrols)
    {
        virtual_key_zp = virtual_key_add(zx, zy, 27 * button_scale, 29 * button_scale, 125);
        virtual_key_xp = virtual_key_add(xx, xy, 27 * button_scale, 29 * button_scale, 124);
        virtual_key_cp = virtual_key_add(cx, cy, 27 * button_scale, 29 * button_scale, 94);
        virtual_key_analogp = virtual_key_add(analog_posx, analog_posy, 59 * analog_scale, 59 * analog_scale, 93);
        virtual_key_settings = virtual_key_add(settingsx, settingsy, 19 * button_scale, 25 * button_scale, 92);
        virtual_key_debug = virtual_key_add(576, 5, 19 * button_scale, 25 * button_scale, 69);
        virtual_key_dual = virtual_key_add(576, 86, 19 * button_scale, 25 * button_scale, 86);
        virtual_key_f2 = virtual_key_add(1, 86, 19 * button_scale, 25 * button_scale, 113);
        
        if (edit != 0)
            exit;
        
        virtual_key_z = virtual_key_add(zx, zy, 27 * button_scale, 29 * button_scale, 90);
        virtual_key_x = virtual_key_add(xx, xy, 27 * button_scale, 29 * button_scale, 88);
        virtual_key_c = virtual_key_add(cx, cy, 27 * button_scale, 29 * button_scale, 67);
        virtual_key_up = virtual_key_add(analog_posx - (arrowkeys_back_area_size * analog_scale), analog_posy - (arrowkeys_back_area_size * analog_scale), (arrowkeys_back_area_size * analog_scale) + ((59 * analog_scale) + (arrowkeys_back_area_size * analog_scale)), (arrowkeys_area_size * analog_scale) + (arrowkeys_back_area_size * analog_scale), 38);
        virtual_key_right = virtual_key_add((analog_posx + (59 * analog_scale)) - (arrowkeys_area_size * analog_scale), analog_posy - (arrowkeys_back_area_size * analog_scale), (arrowkeys_area_size * analog_scale) + (arrowkeys_back_area_size * analog_scale), (arrowkeys_back_area_size * analog_scale) + (59 * analog_scale) + (arrowkeys_back_area_size * analog_scale), 39);
        virtual_key_left = virtual_key_add(analog_posx - (arrowkeys_back_area_size * analog_scale), analog_posy - (arrowkeys_back_area_size * analog_scale), (arrowkeys_area_size * analog_scale) + (arrowkeys_back_area_size * analog_scale), (arrowkeys_back_area_size * analog_scale) + ((59 * analog_scale) + (arrowkeys_back_area_size * analog_scale)), 37);
        virtual_key_down = virtual_key_add(analog_posx - (arrowkeys_back_area_size * analog_scale), (analog_posy + (59 * analog_scale)) - (arrowkeys_area_size * analog_scale), (arrowkeys_back_area_size * analog_scale) + (59 * analog_scale) + (arrowkeys_back_area_size * analog_scale), (arrowkeys_area_size * analog_scale) + (arrowkeys_back_area_size * analog_scale), 40);
        virtual_key_analog = virtual_key_add(analog_posx - (45 * analog_scale), analog_posy - (20 * analog_scale), ((59 + arrowkeys_back_area_size) * analog_scale) + (arrowkeys_back_area_size * analog_scale), (79 * analog_scale) + (20 * analog_scale), 126);
    }
}
else if (instance_exists(obj_mobilecontrols))
{
    audio_play_sound(Windows_Notify_Email, 0, false);
    CC_Add("Current: Disabled");
    
    with (obj_mobilecontrols)
    {
        instance_destroy();
        virtual_key_delete(virtual_key_up);
        virtual_key_delete(virtual_key_down);
        virtual_key_delete(virtual_key_left);
        virtual_key_delete(virtual_key_right);
        virtual_key_delete(virtual_key_z);
        virtual_key_delete(virtual_key_x);
        virtual_key_delete(virtual_key_c);
        virtual_key_delete(virtual_key_zp);
        virtual_key_delete(virtual_key_xp);
        virtual_key_delete(virtual_key_cp);
        virtual_key_delete(virtual_key_analog);
        virtual_key_delete(virtual_key_analogp);
        virtual_key_delete(virtual_key_settings);
        virtual_key_delete(virtual_key_debug);
        virtual_key_delete(virtual_key_dual);
        virtual_key_delete(virtual_key_f2);
    }
}
else
{
    instance_create_depth(0, 0, -15998, obj_mk);
    audio_play_sound(xbox_live_notification, 0, false);
    CC_Add("Current: MobileKey By Crosu");
    
    with (obj_mobilecontrols)
    {
        virtual_key_delete(virtual_key_up);
        virtual_key_delete(virtual_key_down);
        virtual_key_delete(virtual_key_left);
        virtual_key_delete(virtual_key_right);
        virtual_key_delete(virtual_key_z);
        virtual_key_delete(virtual_key_x);
        virtual_key_delete(virtual_key_c);
        virtual_key_delete(virtual_key_zp);
        virtual_key_delete(virtual_key_xp);
        virtual_key_delete(virtual_key_cp);
        virtual_key_delete(virtual_key_analog);
        virtual_key_delete(virtual_key_analogp);
        virtual_key_delete(virtual_key_settings);
        virtual_key_delete(virtual_key_debug);
        virtual_key_delete(virtual_key_dual);
        virtual_key_delete(virtual_key_f2);
    }
}
