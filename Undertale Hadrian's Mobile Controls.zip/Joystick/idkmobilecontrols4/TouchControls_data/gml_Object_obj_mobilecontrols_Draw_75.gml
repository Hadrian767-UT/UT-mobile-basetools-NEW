draw_sprite_ext(spr_black, 0, 0, 0, 1, 1, 0, c_white, black_fade);
draw_set_font(settings_font);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_sprite_ext(spr_controls_config, 0, 220, 22.5, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_button_scale, 0, 120.5, 75, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_arrow_leftright, 0, 459.5, 75, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_analog_scale, 0, 120.5, 121, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_arrow_leftright, 0, 459.5, 121, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_analog_type, 0, 124, 167, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_arrow_leftright, 0, 459.5, 167, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_controls_opacity, 0, 106.5, 213, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_arrow_leftright, 0, 459.5, 213, 2, 2, 0, c_white, text_black_fade);
draw_sprite_ext(spr_reset_config, 0, 241, 412.25, 2, 2, 0, c_white, text_black_fade);
draw_text_colour(settings_num_x, 67, button_scale, c_white, c_white, c_white, c_white, text_black_fade);
draw_text_colour(settings_num_x, 113, analog_scale, c_white, c_white, c_white, c_white, text_black_fade);
draw_text_colour(settings_num_x, 159, joystick_type, c_white, c_white, c_white, c_white, text_black_fade);
draw_text_colour(settings_num_x, 205, controls_opacity, c_white, c_white, c_white, c_white, text_black_fade);
draw_sprite_ext(spr_z_button, keyboard_check(ord("Z")), zx, zy, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_x_button, keyboard_check(ord("X")), xx, xy, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_c_button, keyboard_check(ord("C")), cx, cy, button_scale, button_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_joybase, joystick_type, analog_posx, analog_posy, analog_scale, analog_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_joystick, joystick_type, analog_center_x, analog_center_y, analog_scale, analog_scale, 0, c_white, controls_opacity);
draw_sprite_ext(spr_settings, keyboard_check(92), settingsx, settingsy, 3, 3, 0, c_white, controls_opacity);

if (global.debug_legally == 1)
    draw_sprite_ext(spr_bugbutton, keyboard_check(ord("D")), debugx, debugy, 3, 3, 0, c_white, controls_opacity);

draw_sprite_ext(spr_settings, keyboard_check(47), dualx, dualy, 3, 3, 0, c_rainbow, controls_opacity + 0.3);
draw_sprite_ext(spr_r_button, keyboard_check(vk_f2), f2x, f2y, 3 / 1.2, 3 / 1.2, 0, c_white, controls_opacity);
awa += 1.45;
c_rainbow = make_color_hsv(awa % 223, 255, 200);
