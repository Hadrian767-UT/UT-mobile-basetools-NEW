var analog_touch_id = -1;
var deadzone = 41 * analog_scale;

for (var i = 0; i < 10; i++)
{
    if (device_mouse_check_button(i, mb_left))
    {
        var touch_x = device_mouse_x_to_gui(i);
        var touch_y = device_mouse_y_to_gui(i);
        
        if (touch_x >= (analog_posx - deadzone) && touch_x <= (analog_posx + (59 * analog_scale) + deadzone) && touch_y >= (analog_posy - deadzone) && touch_y <= (analog_posy + (59 * analog_scale) + deadzone))
            analog_touch_id = i;
    }
}

if (analog_touch_id != -1 && device_mouse_check_button(analog_touch_id, mb_left))
{
    var touch_x = device_mouse_x_to_gui(analog_touch_id);
    var touch_y = device_mouse_y_to_gui(analog_touch_id);
    var joy_center_x = analog_posx + ((59 * analog_scale) / 2);
    var joy_center_y = analog_posy + ((59 * analog_scale) / 2);
    var max_radius = (59 * analog_scale) / 2.75;
    var dx = touch_x - joy_center_x;
    var dy = touch_y - joy_center_y;
    var dist = point_distance(joy_center_x, joy_center_y, touch_x, touch_y);
    
    if (dist <= max_radius)
    {
        analog_center_x = touch_x - (21 * analog_scale);
        analog_center_y = touch_y - (21 * analog_scale);
    }
    else
    {
        var dir = point_direction(joy_center_x, joy_center_y, touch_x, touch_y);
        analog_center_x = (joy_center_x + lengthdir_x(max_radius, dir)) - (21 * analog_scale);
        analog_center_y = (joy_center_y + lengthdir_y(max_radius, dir)) - (21 * analog_scale);
    }
}
else
{
    analog_center_x = (analog_posx + ((59 * analog_scale) / 2)) - ((41 * analog_scale) / 2);
    analog_center_y = (analog_posy + ((59 * analog_scale) / 2)) - ((41 * analog_scale) / 2);
    analog_touch_id = -1;
}

if (keyboard_check_pressed(92))
{
    edit += 1;
    
    if (edit == 1)
    {
        black_fade = 0.4;
        text_black_fade = 0.9;
    }
    else if (edit == 2)
    {
        virtual_key_delete(virtual_key_up);
        virtual_key_delete(virtual_key_down);
        virtual_key_delete(virtual_key_left);
        virtual_key_delete(virtual_key_right);
        virtual_key_delete(virtual_key_z);
        virtual_key_delete(virtual_key_x);
        virtual_key_delete(virtual_key_c);
        virtual_key_delete(virtual_key_zp);
        virtual_key_delete(virtual_key_xp);
        virtual_key_delete(virtual_key_cp);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debugp);
        
        virtual_key_delete(virtual_key_dualp);
        virtual_key_delete(virtual_key_f2p);
        virtual_key_delete(virtual_key_analog);
        virtual_key_delete(virtual_key_analogp);
        virtual_key_delete(virtual_key_settings);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debug);
        
        virtual_key_delete(virtual_key_dual);
        virtual_key_delete(virtual_key_f2);
        ini_open("touchconfig.ini");
        ini_write_real("CONFIG", "zx", zx);
        ini_write_real("CONFIG", "zy", zy);
        ini_write_real("CONFIG", "xx", xx);
        ini_write_real("CONFIG", "xy", xy);
        ini_write_real("CONFIG", "cx", cx);
        ini_write_real("CONFIG", "cy", cy);
        
        if (global.debug_legally == 1)
        {
            ini_write_real("CONFIG", "debugx", debugx);
            ini_write_real("CONFIG", "debugy", debugy);
        }
        
        ini_write_real("CONFIG", "dualx", dualx);
        ini_write_real("CONFIG", "dualy", dualy);
        ini_write_real("CONFIG", "f2x", f2x);
        ini_write_real("CONFIG", "f2y", f2y);
        ini_write_real("CONFIG", "analog_posx", analog_posx);
        ini_write_real("CONFIG", "analog_posy", analog_posy);
        ini_write_real("CONFIG", "button_scale", button_scale);
        ini_write_real("CONFIG", "analog_scale", analog_scale);
        ini_write_real("CONFIG", "joystick_type", joystick_type);
        ini_write_real("CONFIG", "controls_opacity", controls_opacity);
        ini_close();
        black_fade = 0;
        text_black_fade = 0;
        edit = 0;
        scr_add_keys();
    }
}

if (edit == 0)
    exit;

virtual_key_delete(virtual_key_up);
virtual_key_delete(virtual_key_down);
virtual_key_delete(virtual_key_left);
virtual_key_delete(virtual_key_right);
virtual_key_delete(virtual_key_z);
virtual_key_delete(virtual_key_x);
virtual_key_delete(virtual_key_c);
virtual_key_delete(virtual_key_zp);
virtual_key_delete(virtual_key_xp);
virtual_key_delete(virtual_key_cp);

if (global.debug_legally == 1)
    virtual_key_delete(virtual_key_debugp);

virtual_key_delete(virtual_key_dualp);
virtual_key_delete(virtual_key_f2p);
virtual_key_delete(virtual_key_analog);
virtual_key_delete(virtual_key_analogp);
virtual_key_delete(virtual_key_settings);

if (global.debug_legally == 1)
    virtual_key_delete(virtual_key_debug);

virtual_key_delete(virtual_key_dual);
virtual_key_delete(virtual_key_f2);
scr_add_keys();

if (keyboard_check(125))
{
    zx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    zy = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(124))
{
    xx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    xy = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(94))
{
    cx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    cy = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(93))
{
    analog_posx = device_mouse_x_to_gui(0) - (29.5 * analog_scale);
    analog_posy = device_mouse_y_to_gui(0) - (29.5 * analog_scale);
}

if (keyboard_check(95) && global.debug_legally == 1)
{
    debugx = device_mouse_x_to_gui(0) - ((19.5 * button_scale) / 1.5);
    debugy = device_mouse_y_to_gui(0) - ((18 * button_scale) / 1.5);
}

if (keyboard_check(vk_numpad0))
{
    dualx = device_mouse_x_to_gui(0) - ((19.5 * button_scale) / 1.5);
    dualy = device_mouse_y_to_gui(0) - ((18 * button_scale) / 1.5);
}

if (keyboard_check(vk_numpad1))
{
    f2x = device_mouse_x_to_gui(0) - ((19.5 * button_scale) / 1.5);
    f2y = device_mouse_y_to_gui(0) - ((18 * button_scale) / 1.5);
}

if (device_mouse_x_to_gui(0) >= 459.5 && device_mouse_y_to_gui(0) >= 75 && device_mouse_x_to_gui(0) <= 469.5 && device_mouse_y_to_gui(0) <= 93 && mouse_check_button_pressed(mb_left))
{
    if (button_scale > 1)
        button_scale -= 0.1;
}

if (device_mouse_x_to_gui(0) >= 531.5 && device_mouse_y_to_gui(0) >= 75 && device_mouse_x_to_gui(0) <= 541.5 && device_mouse_y_to_gui(0) <= 93 && mouse_check_button_pressed(mb_left))
{
    if (button_scale < 3)
        button_scale += 0.1;
}

if (device_mouse_x_to_gui(0) >= 459.5 && device_mouse_y_to_gui(0) >= 121 && device_mouse_x_to_gui(0) <= 469.5 && device_mouse_y_to_gui(0) <= 139 && mouse_check_button_pressed(mb_left))
{
    if (analog_scale > 1)
        analog_scale -= 0.1;
}

if (device_mouse_x_to_gui(0) >= 531.5 && device_mouse_y_to_gui(0) >= 121 && device_mouse_x_to_gui(0) <= 541.5 && device_mouse_y_to_gui(0) <= 139 && mouse_check_button_pressed(mb_left))
{
    if (analog_scale < 4)
        analog_scale += 0.1;
}

if (device_mouse_x_to_gui(0) >= 459.5 && device_mouse_y_to_gui(0) >= 167 && device_mouse_x_to_gui(0) <= 469.5 && device_mouse_y_to_gui(0) <= 185 && mouse_check_button_pressed(mb_left))
{
    if (joystick_type == 1)
        joystick_type -= 1;
}

if (device_mouse_x_to_gui(0) >= 531.5 && device_mouse_y_to_gui(0) >= 167 && device_mouse_x_to_gui(0) <= 541.5 && device_mouse_y_to_gui(0) <= 185 && mouse_check_button_pressed(mb_left))
{
    if (joystick_type == 0)
        joystick_type += 1;
}

if (device_mouse_x_to_gui(0) >= 459.5 && device_mouse_y_to_gui(0) >= 213 && device_mouse_x_to_gui(0) <= 469.5 && device_mouse_y_to_gui(0) <= 231 && mouse_check_button_pressed(mb_left))
{
    if (controls_opacity > 0.1)
        controls_opacity -= 0.05;
}

if (device_mouse_x_to_gui(0) >= 531.5 && device_mouse_y_to_gui(0) >= 213 && device_mouse_x_to_gui(0) <= 541.5 && device_mouse_y_to_gui(0) <= 231 && mouse_check_button_pressed(mb_left))
{
    if (controls_opacity < 1)
        controls_opacity += 0.05;
}

if (device_mouse_x_to_gui(0) >= 241 && device_mouse_y_to_gui(0) >= 412.25 && device_mouse_x_to_gui(0) <= 399 && device_mouse_y_to_gui(0) <= 436.25 && mouse_check_button_pressed(mb_left))
{
    zx = 454;
    zy = 338;
    xx = 538;
    xy = 294;
    cx = 623;
    cy = 253;
    debugx = 576;
    debugy = 5;
    dualx = 576;
    dualy = 86;
    f2x = 75;
    f2y = 5;
    button_scale = 3;
    analog_scale = 3.5;
    analog_posx = -57;
    analog_posy = 225;
    joystick_type = 0;
    controls_opacity = 0.5;
}
